﻿chrome.runtime.sendMessage({
    from: 'content',
    url: window.location.origin
});